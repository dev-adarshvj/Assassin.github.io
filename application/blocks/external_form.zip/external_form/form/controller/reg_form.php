<?php
use CollectionAttributeKey;
use Loader;
use Block;
use Config;
use PageList;
use BlockType;
use TaskPermission;
use PageTemplate;
use PageType;
use Page;
use Permissions;
use AttributeSet;

use UserInfo;
use URL;

defined('C5_EXECUTE') or die(_("Access Denied."));
class RegForm extends DashboardPageController { 
	
	private  $regform = 'regform';
	public function action_regInfo(){
        if($_POST){
          $db=Loader::db();
         $db->query("INSERT INTO $this->regform(name,lname,email,company,region) values(?,?,?,?,?,?)",array($_POST['name'],$_POST['lname'],$_POST['email'],$_POST['company'],$_POST['region']));
         //$this->redirect('/dashboard/pdf_downloader/pdf_list');
        }           }

	///	INSERT INTO `regform`(`id`, `name`, `lname`, `email`, `company`, `region`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6])

} ?>