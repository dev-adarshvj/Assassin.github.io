<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));
$form = Loader::helper('form');
$val = Loader::helper('validation/form');
?>
<form id="contact" name="contact" action="" method="POST">
    <div>
        <label>First Name</label>
        <input placeholder="First Name" type="text" name="name" id="name" tabindex="1" autofocus />
        <div id="name-error" class="error"></div>
    </div>
    <div>
        <label>Last Name</label>
        <input placeholder="Last Name" type="text" name="lname" id="lname" tabindex="2" autofocus />
    </div>
    <div>
        <label>Email</label>
        <input placeholder="Email" type="email" name="email" id="email" tabindex="3" autofocus />
        <div id="email-error" class="error"></div>
    </div>
    <div class="col-md-6 col-12 form-group">
            <select id="company" id="company" class="form-control">
            <option>Company</option>
            <option>Company1</option>
          </select>
          </div>
            <div class="col-12 form-group">
              <select id="region" id="region" class="form-control">
              <option>Select region</option>
              <option>region1</option>
            </select>
            </div>
    <div>
        <label>Disclaimer</label>
        <input type="checkbox" name="terms" id="terms" tabindex="9" autofocus />I confirm that all the above information is true.
        <div id="terms-error" class="error"></div>
    </div>
    <div>
        <button type="submit" name="submit" id="Regsubmit" tabindex="10">Send</button>
    </div>
</form>
<script>
  
$(document).ready(function() {
 
 $("#Regsubmit").click(function(e) {
       e.preventDefault();
       e.stopPropagation();
     var name = $("#name").val();
     var lname = $("#lname").val();
     var email = $("#email").val();
     var company = $("#company").val();
     var region = $("#region").val();
     var terms = $("#terms").val();
     reason = "";
    reason += validateName(contact.name);
    reason += validateEmail(contact.email);
    reason += validateTerms(contact.terms);

    console.log(reason);
    if (reason.length > 0) {

        return false;
    } else {
        alert("Test alert"); // Show some loading image and submit form
        submitFormAjax();
    }
    function validateName(name) {
    var error = "";

    if (name.value.length == 0) {
       // name.style.background = 'Red';
        document.getElementById('name-error').innerHTML = "The required field has not been filled in";
        var error = "1";
    } else {
        name.style.background = 'White';
        document.getElementById('name-error').innerHTML = '';
    }
    return error;
}

// validate email as required field and format
function trim(s) {
    return s.replace(/^\s+|\s+$/, '');
}

function validateEmail(email) {
    var error = "";
    var temail = trim(email.value); // value of field with whitespace trimmed off
    var emailFilter = /^[^@]+@[^@.]+\.[^@]*\w\w$/;
    var illegalChars = /[\(\)\<\>\,\;\:\\\"\[\]]/;

    if (email.value == "") {
        //email.style.background = 'Red';
        document.getElementById('email-error').innerHTML = "Please enter an email address.";
        var error = "2";
    } else if (!emailFilter.test(temail)) { //test email for illegal characters
        //email.style.background = 'Red';
        document.getElementById('email-error').innerHTML = "Please enter a valid email address.";
        var error = "3";
    } else if (email.value.match(illegalChars)) {
       // email.style.background = 'Red';
        var error = "4";
        document.getElementById('email-error').innerHTML = "Email contains invalid characters.";
    } else {
        email.style.background = 'White';
        document.getElementById('email-error').innerHTML = '';
    }
    return error;
}





function validateTerms(terms) {
    var error = "";

    if (document.getElementById("terms").checked === false) {
        document.getElementById('terms-error').innerHTML = "Required";
        var error = "4";
    } else {
        document.getElementById('terms-error').innerHTML = '';
        var disclaimer = document.getElementById("terms").checked;
    }
    return error;
}
function submitFormAjax(){
     $.ajax({
         type: "POST",
         url: "<?= \URL::to('/action_regInfo');?>",
         data: {
             name: name,
             lname: lname,
             email: email,
             company: company,
             region: region,
             terms: terms
         },
         cache: false,
         success: function(data) {
             alert(data);
         },
         error: function(xhr, status, error) {
             console.error(xhr);
         }
     });
    }
      
 });

});
</script>